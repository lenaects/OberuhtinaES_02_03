package com.example.oberuhtinaes_02_03

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton

lateinit var back: ImageButton
lateinit var spin: Spinner
lateinit var metr: EditText
lateinit var but: AppCompatButton
lateinit var rez: TextView
class CalculateActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculate)
        back=findViewById(R.id.imageBack)
        spin=findViewById(R.id.spinner)
        metr=findViewById(R.id.metr)
        but=findViewById(R.id.raschet)
        rez=findViewById(R.id.rezult)
        back.setOnClickListener {
            startActivity(Intent(this@CalculateActivity,MainActivity::class.java))
        }
        val msg= arrayOf("1. 1-о комнатная квартира" ,
            "2. 2-х комнатная квартира" ,
            "3. 3-х комнатная квартира" ,
            "4. Студия",)
        val adapter= ArrayAdapter(
            this,android.R.layout.simple_spinner_item,msg).also { adapter->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spin.adapter=adapter
        spin.setSelection(0)
        but.setOnClickListener {
            val selectedPosition=spin.selectedItemPosition
            val metrInput= metr.text.toString()
            if(metrInput.isNotEmpty()){
                val meters=metrInput.toDouble()
                val price=500.0//стоимость
                var rezult=0.0
                when (selectedPosition) {
                    0 -> rezult = price * meters * 1.4
                    1 -> rezult = price * meters
                    2 -> rezult = price * meters * 0.8
                    3 -> rezult = price * meters * 1.1
                }
                rez.text="$rezult руб"
                val intent= Intent(this@CalculateActivity,RezultActivity::class.java)
                intent.putExtra("metr",metrInput)
                intent.putExtra("rezult",rezult)
                startActivity(intent)
            }
            else{
                Toast.makeText(this,"Введите количество метров", Toast.LENGTH_LONG).show()
            }
        }
    }
}