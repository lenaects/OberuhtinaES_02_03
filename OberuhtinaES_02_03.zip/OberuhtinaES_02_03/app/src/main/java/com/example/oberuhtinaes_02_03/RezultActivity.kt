package com.example.oberuhtinaes_02_03

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton

lateinit var metrs: TextView
lateinit var rezult: TextView
lateinit var regis: AppCompatButton

class RezultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rezult)
        metrs=findViewById(R.id.metr)
        rezult=findViewById(R.id.rezult)
        regis=findViewById(R.id.regist)
        val metrsValue=intent.getStringExtra("metr")
        val rezultValue=intent.getDoubleExtra("rezult",0.0)
        metrs.text="$metrsValue метра"
        rezult.text="$rezultValue руб"
        regis.setOnClickListener {
            val intent= Intent(this@RezultActivity,MainActivity::class.java)
            startActivity(intent)
        }
    }
}