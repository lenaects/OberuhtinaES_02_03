package com.example.oberuhtinaes_02_03

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import com.google.android.material.snackbar.Snackbar

lateinit var  pref: SharedPreferences
lateinit var  login: EditText
lateinit var  pass: EditText
lateinit var regist: AppCompatButton
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login = findViewById(R.id.login)
        pass = findViewById(R.id.password)
        regist = findViewById(R.id.vhod)
        pref = getPreferences(MODE_PRIVATE)
        regist.setOnClickListener {
            val inputLogin = login.text.toString().trim()
            val inputPass = pass.text.toString().trim()

            if (inputLogin.isEmpty() || inputPass.isEmpty()) {
                Snackbar.make(findViewById(android.R.id.content), "Введите логин и пароль", Snackbar.LENGTH_LONG)
                    .setAction("OK") {}
                    .show()
            }
            else {
                if (pref.getString("login", null) == null || pref.getString("pass", null) == null) {
                    with(pref.edit()) {
                        putString("login", inputLogin)
                        putString("pass", inputPass)
                        apply()
                    }
                    startActivity(Intent(this@MainActivity, CalculateActivity::class.java))
                } else {
                    val savedLogin = pref.getString("login", null)
                    val savedPass = pref.getString("pass", null)
                    if (inputLogin == savedLogin && inputPass == savedPass) {
                        startActivity(Intent(this@MainActivity, CalculateActivity::class.java))
                    } else {
                        Snackbar.make(findViewById(android.R.id.content), "Неверный логин или пароль", Snackbar.LENGTH_LONG)
                            .setAction("OK") {}
                            .show()
                    }
                }
            }
        }
    }
}